package com.example.myapplication

import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("get100data")
    fun getDataTopic1(): Call<DataTopic1Response>

    @GET("getDateTime") // Sesuaikan dengan endpoint yang benar untuk mendapatkan waktu
    fun getDateTime(): Call<String> // Ubah sesuai dengan tipe data yang benar (String atau tipe data lainnya)
}